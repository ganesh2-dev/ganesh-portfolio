function sendMail() {
   
    let parms = {
        name: document.getElementById("name").value,
        mail: document.getElementById("email").value,
        message: document.getElementById("message").value
    };

    emailjs.send("service_7rrpqlo", "template_7cvy1ng", parms)
        .then(function(response) {
            alert("Email Sent!!");
        })
        .catch(function(error) {
            console.error("Error sending email: ", error);
        });
}